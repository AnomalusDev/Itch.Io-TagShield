// Fetches each game's page (only when "NSFW deep check" is on) and reports its tags.
// Results are cached for 7 days so each game is only opened once.
const api = typeof browser !== "undefined" ? browser : chrome;

const TTL = 7 * 24 * 3600 * 1000;
const MAX_ENTRIES = 3000;
const MAX_PARALLEL = 2;
const GAME_URL = /^https:\/\/[a-z0-9-]+\.itch\.io\/[^/?#]+\/?$/i;
const GATE_WORDS = /sensitive content|adult content|mature content|nsfw|not suited for minors|over 18|18 years|confirm your age/i;

let cache = null;
let saveTimer = null;
const inflight = new Map();
const queue = [];
let active = 0;

async function loadCache() {
  if (cache) return;
  const d = await api.storage.local.get({ tsCache: {} });
  cache = d.tsCache || {};
}

function scheduleSave() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    const now = Date.now();
    let keys = Object.keys(cache);
    keys.forEach((k) => { if (now - cache[k].t > TTL) delete cache[k]; });
    keys = Object.keys(cache);
    if (keys.length > MAX_ENTRIES) {
      keys.sort((a, b) => cache[a].t - cache[b].t)
          .slice(0, keys.length - MAX_ENTRIES)
          .forEach((k) => delete cache[k]);
    }
    api.storage.local.set({ tsCache: cache });
  }, 1500);
}

async function fetchGame(url) {
  const res = await fetch(url, { credentials: "include" });
  if (!res.ok) throw new Error("HTTP " + res.status);
  const html = await res.text();
  const doc = new DOMParser().parseFromString(html, "text/html");

  const panel = doc.querySelector(".game_info_panel_widget");
  const scope = panel || doc;
  const tags = new Set();
  scope.querySelectorAll('a[href*="tag-"]').forEach((a) => {
    const href = a.getAttribute("href") || "";
    for (const m of href.matchAll(/tag-([^/?#]+)/g)) {
      try { tags.add(decodeURIComponent(m[1]).toLowerCase()); } catch (e) {}
    }
  });

  // A page without the info panel is probably an age/sensitive-content gate.
  const gate = !panel && GATE_WORDS.test(doc.body ? doc.body.textContent : "");
  return { tags: [...tags], gate, t: Date.now() };
}

function enqueue(url) {
  return new Promise((resolve) => {
    queue.push({ url, resolve });
    pump();
  });
}

function pump() {
  while (active < MAX_PARALLEL && queue.length) {
    const job = queue.shift();
    active++;
    fetchGame(job.url)
      .then((r) => {
        cache[job.url] = r;
        scheduleSave();
        job.resolve(r);
      })
      .catch(() => job.resolve({ error: true }))
      .finally(() => {
        active--;
        setTimeout(pump, 150);
      });
  }
}

async function check(url) {
  if (!GAME_URL.test(url)) return { error: true };
  await loadCache();
  const hit = cache[url];
  if (hit && Date.now() - hit.t < TTL) return hit;
  if (!inflight.has(url)) {
    inflight.set(url, enqueue(url).finally(() => inflight.delete(url)));
  }
  return inflight.get(url);
}

api.runtime.onMessage.addListener((msg) => {
  if (msg && msg.type === "tsCheck") return check(msg.url);
});
