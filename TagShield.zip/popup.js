const api = typeof browser !== "undefined" ? browser : chrome;

const DEFAULT_GENRES = [
  "Action", "Adventure", "Card Game", "Educational", "Fighting",
  "Interactive Fiction", "Platformer", "Puzzle", "Racing", "Role Playing",
  "Shooter", "Simulation", "Sports", "Strategy", "Survival", "Visual Novel", "Other"
];

const norm = (s) => s.trim().toLowerCase();
const $ = (id) => document.getElementById(id);

let state = {
  hiddenGenres: ["visual novel"],
  customGenres: [],
  enabled: true,
  nsfw: false,
  nsfwDeep: true,
  nsfwExtra: ""
};

async function save() {
  await api.storage.local.set(state);
}

function render() {
  $("enabled").checked = state.enabled;
  $("nsfw").checked = state.nsfw;
  $("nsfwDeep").checked = state.nsfwDeep;
  $("nsfwExtra").value = state.nsfwExtra;
  const list = $("list");
  list.innerHTML = "";
  const genres = [...DEFAULT_GENRES, ...state.customGenres];
  genres.forEach((name) => {
    const label = document.createElement("label");
    label.className = "row";
    const cb = document.createElement("input");
    cb.type = "checkbox";
    cb.checked = state.hiddenGenres.includes(norm(name));
    cb.addEventListener("change", () => {
      const key = norm(name);
      const set = new Set(state.hiddenGenres);
      cb.checked ? set.add(key) : set.delete(key);
      state.hiddenGenres = [...set];
      save();
    });
    const span = document.createElement("span");
    span.textContent = name;
    label.append(cb, span);
    list.appendChild(label);
  });
}

async function init() {
  const data = await api.storage.local.get(state);
  state = { ...state, ...data };
  render();
}

$("enabled").addEventListener("change", (e) => {
  state.enabled = e.target.checked;
  save();
});

$("nsfw").addEventListener("change", (e) => {
  state.nsfw = e.target.checked;
  save();
});
$("nsfwDeep").addEventListener("change", (e) => {
  state.nsfwDeep = e.target.checked;
  save();
});
$("nsfwExtra").addEventListener("change", (e) => {
  state.nsfwExtra = e.target.value;
  save();
});

function addCustom() {
  const v = $("custom").value.trim();
  if (!v) return;
  const exists = [...DEFAULT_GENRES, ...state.customGenres].some((g) => norm(g) === norm(v));
  if (!exists) state.customGenres.push(v);
  const set = new Set(state.hiddenGenres);
  set.add(norm(v));
  state.hiddenGenres = [...set];
  $("custom").value = "";
  save();
  render();
}
$("addBtn").addEventListener("click", addCustom);
$("custom").addEventListener("keydown", (e) => { if (e.key === "Enter") addCustom(); });

$("all").addEventListener("click", () => {
  state.hiddenGenres = [...DEFAULT_GENRES, ...state.customGenres].map(norm);
  save(); render();
});
$("none").addEventListener("click", () => {
  state.hiddenGenres = [];
  save(); render();
});

init();
