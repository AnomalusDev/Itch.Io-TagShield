const api = typeof browser !== "undefined" ? browser : chrome;

// Tags (as they appear in itch.io URLs: tag-xxx) treated as NSFW
const DEFAULT_NSFW_TAGS = [
  "nsfw", "adult", "erotic", "eroge", "hentai", "porn", "pornographic",
  "lewd", "ecchi", "18", "18-plus", "18plus", "sexual-content", "adult-only"
];
// Words looked for directly in a card's title/description
const DEFAULT_CARD_WORDS = ["nsfw", "hentai", "eroge", "erotic", "porn", "lewd", "ecchi", "18+"];

const FAILED = "failed";
const GAME_URL = /^https:\/\/[a-z0-9-]+\.itch\.io\/[^/?#]+\/?$/i;

let hidden = new Set();
let enabled = true;
let nsfwOn = false;
let deepOn = true;
let nsfwTags = new Set(DEFAULT_NSFW_TAGS);
let wordRe = null;

const results = new Map(); // game url -> { tags, gate } | FAILED
const pending = new Set();

const norm = (s) => (s || "").trim().toLowerCase();
const slug = (s) => norm(s).replace(/\s+/g, "-");
const escapeRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

const style = document.createElement("style");
style.textContent = "[data-ih-hidden]{display:none !important;}";
document.documentElement.appendChild(style);

function cellUrl(cell) {
  const a = cell.querySelector("a.game_link, a.title, a.thumb_link, a[href]");
  if (!a || !a.href) return null;
  try {
    const u = new URL(a.href);
    return u.origin + u.pathname;
  } catch (e) {
    return null;
  }
}

function isNsfwResult(r) {
  return !!r && r !== FAILED && (r.gate || r.tags.some((t) => nsfwTags.has(t)));
}

function shouldHide(cell) {
  const el = cell.querySelector(".game_genre");
  const genre = el ? norm(el.textContent) : "";
  if (genre && hidden.has(genre)) return true;

  if (nsfwOn) {
    if (wordRe && wordRe.test(cell.textContent)) return true;
    const url = cellUrl(cell);
    if (url && isNsfwResult(results.get(url))) return true;
  }
  return false;
}

function requestCheck(url) {
  pending.add(url);
  api.runtime
    .sendMessage({ type: "tsCheck", url })
    .then((r) => results.set(url, r && !r.error ? r : FAILED))
    .catch(() => results.set(url, FAILED))
    .finally(() => {
      pending.delete(url);
      scheduleApply();
    });
}

function apply() {
  document.querySelectorAll(".game_cell").forEach((cell) => {
    if (enabled && shouldHide(cell)) {
      cell.setAttribute("data-ih-hidden", "1");
    } else {
      cell.removeAttribute("data-ih-hidden");
    }

    if (enabled && nsfwOn && deepOn) {
      const url = cellUrl(cell);
      if (url && GAME_URL.test(url) && !results.has(url) && !pending.has(url)) {
        requestCheck(url);
      }
    }
  });
}

let scheduled = false;
function scheduleApply() {
  if (scheduled) return;
  scheduled = true;
  requestAnimationFrame(() => {
    scheduled = false;
    apply();
  });
}

async function load() {
  const data = await api.storage.local.get({
    hiddenGenres: ["visual novel"],
    enabled: true,
    nsfw: false,
    nsfwDeep: true,
    nsfwExtra: "",
  });
  hidden = new Set(data.hiddenGenres.map(norm));
  enabled = data.enabled;
  nsfwOn = data.nsfw;
  deepOn = data.nsfwDeep;

  const extra = data.nsfwExtra.split(",").map(norm).filter(Boolean);
  nsfwTags = new Set([...DEFAULT_NSFW_TAGS, ...extra.map(slug)]);
  const words = [...new Set([...DEFAULT_CARD_WORDS, ...extra])];
  wordRe = new RegExp(
    words.map((w) => "(?<![a-z0-9])" + escapeRe(w) + "(?![a-z0-9])").join("|"),
    "i"
  );
  apply();
}

const SETTING_KEYS = ["hiddenGenres", "enabled", "nsfw", "nsfwDeep", "nsfwExtra"];
api.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && SETTING_KEYS.some((k) => k in changes)) load();
});

new MutationObserver(scheduleApply).observe(document.body, {
  childList: true,
  subtree: true,
});

load();
